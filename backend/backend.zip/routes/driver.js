const express = require('express');
const multer = require('multer');
const path = require('path');
const Driver = require('../model/driver');
const apiKeyAuth = require('../middleware/apiKeyAuth'); 
const router = express.Router();

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../src/assets/upload'));
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});

const upload = multer({ storage: storage });
router.post('/create',apiKeyAuth, upload.fields([
    { name: 'aadhar', maxCount: 1 },
    { name: 'voter', maxCount: 1 },
    { name: 'dl', maxCount: 1 },
    { name: 'profile_pic', maxCount: 1 }
]), async (req, res) => {
    try {
        const { files } = req;
        const driverData = {
            ...req.body,
            aadhar: files.aadhar ? files.aadhar[0].path : null,
            voter: files.voter ? files.voter[0].path : null,
            dl: files.dl ? files.dl[0].path : null,
            profile_pic: files.profile_pic ? files.profile_pic[0].path : null
        };
        const driver = new Driver(driverData);
        const savedDriver = await driver.save();

        res.status(201).json({ message: 'Driver created successfully', driver: savedDriver });
    } catch (error) {
        res.status(500).json({ message: 'Error creating driver', error });
    }
});

module.exports = router;
